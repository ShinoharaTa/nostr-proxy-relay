import type {
  MockFeature,
  MockIpRule,
  MockKpi,
  MockLiveEvent,
  MockRejectionByReason,
  MockRelayInfo,
  MockSeriesPoint,
  MockTopIp,
  MockTopNpub,
  MockUseCase,
  ThemeMeta,
} from './types';

export const RELAY_INFO: MockRelayInfo = {
  name: 'PROXYRELAY-JP',
  description:
    '日本ユーザー向けの公開Nostrリレー。バックエンドは複数の主要リレーへフェイルオーバーし、IP/Npub レイヤで悪意ある投稿を前段ブロック。',
  region: 'TYO / JP',
  policy: 'denylist',
  supported_nips: [1, 2, 4, 9, 11, 22, 28, 33, 40, 42, 50, 65],
  contact: 'admin@proxyrelay.jp',
  url: 'wss://proxyrelay.jp',
};

export const KPI: MockKpi = {
  active_connections: 142,
  posted_per_min: 87,
  delivered_per_min: 2436,
  rejected_per_min: 17,
  uptime_label: '4d 12h 33m',
  uptime_seconds: 390780,
};

export const SERIES: MockSeriesPoint[] = (() => {
  const out: MockSeriesPoint[] = [];
  const now = Date.now();
  for (let i = 23; i >= 0; i--) {
    const t = new Date(now - i * 60_000 * 5);
    const baseDeliv = 200 + Math.round(Math.sin(i / 3) * 50 + Math.random() * 60);
    out.push({
      time: `${String(t.getHours()).padStart(2, '0')}:${String(t.getMinutes()).padStart(2, '0')}`,
      posted: 8 + Math.round(Math.random() * 12),
      delivered: baseDeliv,
      rejected: Math.round(Math.random() * 6),
    });
  }
  return out;
})();

export const FEATURES: MockFeature[] = [
  {
    title: 'POST policy switch',
    body: 'Allowlist と Denylist をワンクリックで切替。自分専用にも公開リレーにも。',
    icon: '⌥',
  },
  {
    title: 'IP ACL with CIDR',
    body: 'Hard / Shadow / Whitelist の3モード。CIDR で範囲指定、追加直後の接続も強制切断。',
    icon: '#',
  },
  {
    title: 'Quarantine',
    body: '騒がしい npub を一時的に黙らせる時限ミュート。BAN するほどでもないノイズに最適。',
    icon: '◉',
  },
  {
    title: 'Live monitoring',
    body: 'Server-Sent Events で接続/投稿/拒否をリアルタイム可視化。何が起きたかを後追いせず即把握。',
    icon: '⌁',
  },
  {
    title: 'NIP-11 enforcement',
    body: '宣言した最大長・タグ数・購読数をサーバ側で本当に強制。ボット対策の最前線。',
    icon: '✓',
  },
  {
    title: 'Filter DSL + Simple BAN',
    body: 'GUI ルールも DSL も同じエンジンで評価。POST と REQ どちらに効かせるかも個別設定。',
    icon: '∆',
  },
];

export const USE_CASES: MockUseCase[] = [
  {
    title: '自分専用リレー',
    body: 'Allowlist + Whitelist で自分とフォロイーだけが POST できる、保守なしの完全プライベート空間。',
  },
  {
    title: '日本コミュニティの公開リレー',
    body: 'Denylist で誰でも書けるが、悪質な npub / IP は Hard BAN や Shadow BAN で迅速に遮断。',
  },
  {
    title: '前段防御プロキシ',
    body: 'バックエンドのリソースを浪費させる前に NIP-11 制限とフィルタで遮断する SecOps 用途。',
  },
];

export const IP_RULES: MockIpRule[] = [
  { ip: '192.0.2.10', mode: 'hard_ban', is_cidr: false, memo: 'spam burst 04-12' },
  { ip: '198.51.100.0/24', mode: 'shadow_ban', is_cidr: true, memo: 'noisy datacenter' },
  { ip: '203.0.113.42', mode: 'whitelist', is_cidr: false, memo: 'admin home VPN' },
  { ip: '2001:db8:1::/48', mode: 'shadow_ban', is_cidr: true, memo: 'auto-injected' },
  { ip: '203.0.113.99', mode: 'hard_ban', is_cidr: false, memo: 'duplicate kind:1' },
];

export const LIVE_EVENTS: MockLiveEvent[] = [
  {
    ts: '14:22:08',
    type: 'event_accepted',
    kind: 1,
    npub: 'npub1az9...vk2',
    ip: '192.0.2.55',
  },
  {
    ts: '14:22:08',
    type: 'event_delivered',
    kind: 1,
    npub: 'npub1az9...vk2',
    sub_id: 'sub:home',
  },
  {
    ts: '14:22:07',
    type: 'event_rejected',
    kind: 1,
    npub: 'npub1xxx...spm',
    ip: '198.51.100.7',
    reason: 'shadow_ban',
  },
  {
    ts: '14:22:06',
    type: 'connection_opened',
    ip: '192.0.2.55',
  },
  {
    ts: '14:22:05',
    type: 'event_delivered',
    kind: 7,
    npub: 'npub1q8h...n2k',
    sub_id: 'sub:reactions',
  },
  {
    ts: '14:22:04',
    type: 'event_dropped',
    kind: 6,
    npub: 'npub1pp9...drp',
    sub_id: 'sub:home',
    reason: 'simple_ban_kind',
  },
  {
    ts: '14:22:03',
    type: 'event_accepted',
    kind: 1,
    npub: 'npub1jp1...kt9',
    ip: '203.0.113.5',
  },
  {
    ts: '14:22:02',
    type: 'event_rejected',
    kind: 1,
    npub: 'npub1bot...000',
    ip: '198.51.100.0',
    reason: 'banned_ip',
  },
  {
    ts: '14:22:00',
    type: 'connection_closed',
    ip: '192.0.2.31',
  },
  {
    ts: '14:21:59',
    type: 'event_delivered',
    kind: 1,
    npub: 'npub1zap...lol',
    sub_id: 'sub:zap',
  },
  {
    ts: '14:21:58',
    type: 'event_accepted',
    kind: 9735,
    npub: 'npub1zap...lol',
    ip: '203.0.113.10',
  },
  {
    ts: '14:21:55',
    type: 'event_dropped',
    kind: 1,
    npub: 'npub1bot...001',
    sub_id: 'sub:home',
    reason: 'filter_rule',
  },
];

export const REJECTIONS_BY_REASON: MockRejectionByReason[] = [
  { reason: 'banned_ip', count: 412 },
  { reason: 'shadow_ban', count: 298 },
  { reason: 'kind_blacklist', count: 167 },
  { reason: 'filter_rule', count: 88 },
  { reason: 'not_in_post_policy', count: 41 },
];

export const TOP_NPUBS: MockTopNpub[] = [
  { npub: 'npub1bot...001', count: 312 },
  { npub: 'npub1xxx...spm', count: 184 },
  { npub: 'npub1pp9...drp', count: 95 },
  { npub: 'npub1zzz...zzz', count: 41 },
];

export const TOP_IPS: MockTopIp[] = [
  { ip: '198.51.100.7', count: 220 },
  { ip: '192.0.2.10', count: 188 },
  { ip: '203.0.113.99', count: 71 },
  { ip: '198.51.100.42', count: 33 },
];

// ── Theme catalog ──────────────────────────────────────────────────────────

export const THEMES: ThemeMeta[] = [
  {
    id: 'terminal',
    name: 'TERMINAL',
    tagline: 'CRT green-on-black, scan lines, monospace operators console',
    description: 'Mr. Robot / hacker movie 風。緑文字の CRT、走査線、等幅。',
    palette: ['#000000', '#0d2b0d', '#5cff5c', '#9dff9d'],
  },
  {
    id: 'nasa',
    name: 'NASA',
    tagline: 'Mission control: deep navy, amber & cyan, dense telemetry',
    description: 'NASA / SpaceX Mission Control 風。深い navy + amber/cyan、表とゲージ多め。',
    palette: ['#04101e', '#0d2746', '#ffb300', '#3ad6ff'],
  },
  {
    id: 'tron',
    name: 'TRON',
    tagline: 'Black grid + cyan glow, lines that breathe',
    description: 'Tron Legacy のグリッド + cyan 発光。線で構成された幾何学的な UI。',
    palette: ['#000000', '#001b22', '#00f0ff', '#00ffd5'],
  },
  {
    id: 'alien',
    name: 'ALIEN',
    tagline: 'Nostromo battle console, red on black + hazard stripes',
    description: 'Alien Nostromo 風。red/black 主体 + 黒黄ストライプの警告色。緊迫感。',
    palette: ['#0a0a0a', '#290000', '#ff2a2a', '#ffd500'],
  },
  {
    id: 'synthwave',
    name: 'SYNTHWAVE',
    tagline: '80s sun grid, magenta & cyan, neon haze',
    description: '80年代 sun grid。pink/purple + cyan のネオン、grid horizon。',
    palette: ['#0d0221', '#241734', '#ff2a92', '#41ead4'],
  },
  {
    id: 'bladerunner',
    name: 'BLADE RUNNER',
    tagline: 'Warm amber dust, dim glass, futurist serif',
    description: 'Blade Runner 2049 のロビー UI 風。warm amber + 薄暗、ダスト粒子。',
    palette: ['#0b0903', '#1a1108', '#e9a73a', '#ff7a18'],
  },
  {
    id: 'watchdogs',
    name: 'WATCH_DOGS',
    tagline: 'ctOS city surveillance HUD, lime + cyan + hot pink',
    description: 'Watch Dogs ctOS 風。都市監視ハッカー HUD、ノードグラフ背景、角タグ・データブロック。',
    palette: ['#0a0d0e', '#16191b', '#b3ff45', '#ff2e88'],
  },
  {
    id: 'cyberpunk',
    name: 'CYBERPUNK',
    tagline: 'Yellow + magenta neon, glitch noise, katakana',
    description: 'Cyberpunk 2077 / 攻殻 Phone 風。黒 + 蛍光黄 + マゼンタ、グリッチ歪み、片仮名ダミー。',
    palette: ['#0a0a14', '#150f1c', '#fcee0a', '#ff007a'],
  },
  {
    id: 'ratchet',
    name: 'RATCHET',
    tagline: 'Bright sci-fi toon, cobalt + chrome + orange',
    description: 'Ratchet & Clank / Pixar SF 風。明るめトゥーン、ホログラム枠、丸み、ガジェット感。',
    palette: ['#102448', '#1d3a72', '#ff8a1f', '#a4d8ff'],
  },
  {
    id: 'gta_phone',
    name: 'GTA PHONE',
    tagline: 'Light theme iFruit-style flat phone OS',
    description: 'GTA V iFruit 風スマホ UI。唯一のライトテーマ。フラットアプリタイル + ライム + ベリー。',
    palette: ['#f4f5f7', '#ffffff', '#88c100', '#e91e63'],
  },
  {
    id: 'lol',
    name: 'LEAGUE',
    tagline: 'eSports lobby, hexagon + gold filigree on navy',
    description: 'League of Legends クライアント風。紺 + 金箔 + ティール、ヘキサゴン枠、紋章タイポ。',
    palette: ['#010a13', '#0a1428', '#c8aa6e', '#0bc6e3'],
  },
  {
    id: 'apex',
    name: 'APEX',
    tagline: 'Battle royale tactical HUD, orange + slash diagonals',
    description: 'Apex Legends タクティカル HUD 風。黒 + 白 + オレンジ、シールド/ヘルスバー、斜めライン。',
    palette: ['#0c0d0f', '#1a1d22', '#ff4d1a', '#d33b3b'],
  },
  {
    id: 'hybrid',
    name: 'CRT_OPS',
    tagline: 'Cyberpunk type × APEX slash × Terminal scan line',
    description:
      'Cyberpunk のグリッチ文字 + APEX の右上スラッシュ角・左バー + Terminal の CRT 走査線を融合。蛍光イエロー基調 + マゼンタ警告 + 緑 info、片仮名サイドレール付き。',
    palette: ['#000000', '#0c0c10', '#fcee0a', '#5cff5c'],
  },
];
