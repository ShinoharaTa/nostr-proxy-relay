import { Routes, Route, Navigate } from 'react-router-dom';
import { MockIndex } from './MockIndex';
import { ThemeIndex } from './ThemeIndex';
import { LpTemplate } from './shared/LpTemplate';
import { DashboardTemplate } from './shared/DashboardTemplate';
import { ConfigSampleTemplate } from './shared/ConfigSampleTemplate';
import './shared/mock.css';

// Theme-specific CSS files. Each one defines `.theme-{id}` overrides + decoration helpers.
import './themes/terminal/theme.css';
import './themes/nasa/theme.css';
import './themes/tron/theme.css';
import './themes/alien/theme.css';
import './themes/synthwave/theme.css';
import './themes/bladerunner/theme.css';
import './themes/watchdogs/theme.css';
import './themes/cyberpunk/theme.css';
import './themes/ratchet/theme.css';
import './themes/gta_phone/theme.css';
import './themes/lol/theme.css';
import './themes/apex/theme.css';
import './themes/hybrid/theme.css';

import { TerminalDecoration } from './themes/terminal/decoration';
import { NasaDecoration } from './themes/nasa/decoration';
import { TronDecoration } from './themes/tron/decoration';
import { AlienDecoration } from './themes/alien/decoration';
import { SynthwaveDecoration } from './themes/synthwave/decoration';
import { BladerunnerDecoration } from './themes/bladerunner/decoration';
import { WatchdogsDecoration } from './themes/watchdogs/decoration';
import { CyberpunkDecoration } from './themes/cyberpunk/decoration';
import { RatchetDecoration } from './themes/ratchet/decoration';
import { GtaPhoneDecoration } from './themes/gta_phone/decoration';
import { LolDecoration } from './themes/lol/decoration';
import { ApexDecoration } from './themes/apex/decoration';
import { HybridDecoration } from './themes/hybrid/decoration';

import { THEMES } from './fixtures';
import type { ThemeId } from './types';
import type { ReactNode } from 'react';

const DECORATIONS: Record<ThemeId, ReactNode> = {
  terminal: <TerminalDecoration />,
  nasa: <NasaDecoration />,
  tron: <TronDecoration />,
  alien: <AlienDecoration />,
  synthwave: <SynthwaveDecoration />,
  bladerunner: <BladerunnerDecoration />,
  watchdogs: <WatchdogsDecoration />,
  cyberpunk: <CyberpunkDecoration />,
  ratchet: <RatchetDecoration />,
  gta_phone: <GtaPhoneDecoration />,
  lol: <LolDecoration />,
  apex: <ApexDecoration />,
  hybrid: <HybridDecoration />,
};

export function MockApp() {
  return (
    <Routes>
      <Route index element={<MockIndex />} />
      {THEMES.map(t => (
        <Route key={t.id} path={t.id} element={<ThemeIndex theme={t} />} />
      ))}
      {THEMES.map(t => (
        <Route
          key={`${t.id}-lp`}
          path={`${t.id}/lp`}
          element={<LpTemplate themeId={t.id} decoration={DECORATIONS[t.id]} />}
        />
      ))}
      {THEMES.map(t => (
        <Route
          key={`${t.id}-dash`}
          path={`${t.id}/dashboard`}
          element={<DashboardTemplate themeId={t.id} decoration={DECORATIONS[t.id]} />}
        />
      ))}
      {THEMES.map(t => (
        <Route
          key={`${t.id}-cfg`}
          path={`${t.id}/config`}
          element={<ConfigSampleTemplate themeId={t.id} decoration={DECORATIONS[t.id]} />}
        />
      ))}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
