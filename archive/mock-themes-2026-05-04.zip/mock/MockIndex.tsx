import { Link } from 'react-router-dom';
import { THEMES } from './fixtures';

export function MockIndex() {
  return (
    <div className="mock-index">
      <header className="mock-index-head">
        <span className="mock-index-eyebrow">// SF CONSOLE UI / THEME PREVIEW</span>
        <h1 className="mock-index-title">PROXYRELAY MOCK GALLERY</h1>
        <p className="mock-index-lead">
          /mock 配下に SF コンソール調 13 テーマを並べたモックです。各テーマで LP / Dashboard / Config の 3 画面を確認できます。
          採用テーマは <strong>PROFILER</strong>（WATCH_DOGS 1 / ctOS / Profiler ベース、装飾を抑えた監視 HUD）。
          公開 LP はトップ <code>/</code> に、管理コンソールは <code>/console</code> に実装されています。
        </p>
      </header>

      <div className="mock-index-grid">
        {THEMES.map(t => (
          <article className="mock-index-card" key={t.id}>
            <div className="mock-index-card-head">
              <h2>{t.name}</h2>
              <span className="mock-index-card-id">/mock/{t.id}</span>
            </div>
            <p className="mock-index-card-tagline">{t.tagline}</p>
            <p className="mock-index-card-desc">{t.description}</p>
            <div className="mock-index-palette">
              {t.palette.map(c => (
                <span key={c} style={{ background: c }} title={c} />
              ))}
            </div>
            <div className="mock-index-card-actions">
              <Link to={`${t.id}/lp`}>LP</Link>
              <Link to={`${t.id}/dashboard`}>DASHBOARD</Link>
              <Link to={`${t.id}/config`}>CONFIG</Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
