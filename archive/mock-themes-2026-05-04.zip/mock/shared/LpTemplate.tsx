import type { ReactNode } from 'react';
import {
  KPI,
  RELAY_INFO,
  FEATURES,
  USE_CASES,
  LIVE_EVENTS,
} from '../fixtures';

interface Props {
  themeId: string;
  decoration?: ReactNode;
}

export function LpTemplate({ themeId, decoration }: Props) {
  return (
    <div className={`mock mock-lp theme-${themeId}`} data-theme={themeId}>
      {decoration}
      <header className="mock-topbar">
        <div className="mock-brand">
          <span className="mock-mark" />
          <span className="mock-brand-name">{RELAY_INFO.name}</span>
        </div>
        <div className="mock-topbar-meta">
          <span className="mock-status-dot" />
          <span>STATUS: ONLINE</span>
          <span className="mock-divider" />
          <span>{RELAY_INFO.region}</span>
          <span className="mock-divider" />
          <a href={RELAY_INFO.url} className="mock-link">{RELAY_INFO.url}</a>
        </div>
      </header>

      <section className="mock-hero">
        <div className="mock-hero-inner">
          <div className="mock-eyebrow">// PROXY NOSTR RELAY</div>
          <h1 className="mock-headline">
            悪意は前段で止め、<br />届くべき声だけ流す
          </h1>
          <p className="mock-subhead">{RELAY_INFO.description}</p>
          <div className="mock-cta-row">
            <a className="mock-btn mock-btn-primary" href={RELAY_INFO.url}>
              CONNECT  →  {RELAY_INFO.url}
            </a>
            <a className="mock-btn mock-btn-secondary" href="https://github.com/ShinoharaTa/nostr-proxy-relay">
              SOURCE
            </a>
          </div>
        </div>
        <div className="mock-hero-side">
          <div className="mock-stat-card">
            <span className="mock-stat-label">ACTIVE</span>
            <span className="mock-stat-value">{KPI.active_connections}</span>
            <span className="mock-stat-unit">connections</span>
          </div>
          <div className="mock-stat-card">
            <span className="mock-stat-label">DELIVERED</span>
            <span className="mock-stat-value">{KPI.delivered_per_min.toLocaleString()}</span>
            <span className="mock-stat-unit">events / min</span>
          </div>
          <div className="mock-stat-card">
            <span className="mock-stat-label">UPTIME</span>
            <span className="mock-stat-value">{KPI.uptime_label}</span>
            <span className="mock-stat-unit">since last restart</span>
          </div>
          <div className="mock-stat-card">
            <span className="mock-stat-label">REJECT</span>
            <span className="mock-stat-value">{KPI.rejected_per_min}</span>
            <span className="mock-stat-unit">events / min blocked</span>
          </div>
        </div>
      </section>

      <section className="mock-section">
        <div className="mock-section-head">
          <span className="mock-section-no">01</span>
          <h2 className="mock-section-title">CAPABILITIES</h2>
          <span className="mock-section-rule" />
        </div>
        <div className="mock-feature-grid">
          {FEATURES.map(f => (
            <article className="mock-feature" key={f.title}>
              <span className="mock-feature-icon">{f.icon}</span>
              <h3>{f.title}</h3>
              <p>{f.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mock-section">
        <div className="mock-section-head">
          <span className="mock-section-no">02</span>
          <h2 className="mock-section-title">USE CASES</h2>
          <span className="mock-section-rule" />
        </div>
        <div className="mock-usecase-row">
          {USE_CASES.map((u, i) => (
            <article className="mock-usecase" key={u.title}>
              <span className="mock-usecase-no">U-0{i + 1}</span>
              <h3>{u.title}</h3>
              <p>{u.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mock-section">
        <div className="mock-section-head">
          <span className="mock-section-no">03</span>
          <h2 className="mock-section-title">LIVE TRAFFIC (sample)</h2>
          <span className="mock-section-rule" />
        </div>
        <div className="mock-ticker">
          {LIVE_EVENTS.slice(0, 8).map((ev, i) => (
            <div className={`mock-ticker-row ev-${ev.type}`} key={i}>
              <span className="mock-ticker-time">{ev.ts}</span>
              <span className="mock-ticker-type">{ev.type.toUpperCase()}</span>
              <span className="mock-ticker-detail">
                {ev.kind != null && `kind=${ev.kind} `}
                {ev.npub && `${ev.npub} `}
                {ev.ip && `ip=${ev.ip} `}
                {ev.reason && `reason=${ev.reason}`}
                {ev.sub_id && `sub=${ev.sub_id}`}
              </span>
            </div>
          ))}
        </div>
      </section>

      <footer className="mock-footer">
        <span>{RELAY_INFO.name}  ·  {RELAY_INFO.contact}</span>
        <span>NIP-{RELAY_INFO.supported_nips.slice(0, 6).join(' / NIP-')} +{RELAY_INFO.supported_nips.length - 6}</span>
        <span>BUILD //  v0.4.0-mock</span>
      </footer>
    </div>
  );
}
