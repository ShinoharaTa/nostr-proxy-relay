import type { ReactNode } from 'react';
import {
  KPI,
  RELAY_INFO,
  REJECTIONS_BY_REASON,
  SERIES,
  TOP_IPS,
  TOP_NPUBS,
} from '../fixtures';

interface Props {
  themeId: string;
  decoration?: ReactNode;
}

export function DashboardTemplate({ themeId, decoration }: Props) {
  const maxRejection = Math.max(
    ...REJECTIONS_BY_REASON.map(r => r.count),
    1,
  );
  const maxNpub = Math.max(...TOP_NPUBS.map(r => r.count), 1);
  const maxIp = Math.max(...TOP_IPS.map(r => r.count), 1);
  const maxSeries = Math.max(...SERIES.flatMap(s => [s.posted, s.delivered, s.rejected]), 1);

  return (
    <div className={`mock mock-dash theme-${themeId}`} data-theme={themeId}>
      {decoration}
      <header className="mock-dash-head">
        <div>
          <span className="mock-eyebrow">// CONSOLE / OVERVIEW</span>
          <h1 className="mock-dash-title">{RELAY_INFO.name} · OPS</h1>
        </div>
        <div className="mock-dash-meta">
          <span className="mock-status-dot" />
          <span>OPERATIONAL</span>
          <span className="mock-divider" />
          <span>UTC {new Date().toISOString().slice(11, 19)}</span>
          <span className="mock-divider" />
          <span>UPTIME {KPI.uptime_label}</span>
        </div>
      </header>

      <section className="mock-kpi-row">
        <KpiCard label="ACTIVE CONNECTIONS" value={KPI.active_connections.toString()} unit="now" trend="+12" />
        <KpiCard label="POSTED / MIN" value={KPI.posted_per_min.toString()} unit="events" trend="+3" />
        <KpiCard label="DELIVERED / MIN" value={KPI.delivered_per_min.toLocaleString()} unit="events" trend="+182" />
        <KpiCard label="REJECTED / MIN" value={KPI.rejected_per_min.toString()} unit="events" trend="-2" tone="warn" />
      </section>

      <section className="mock-panel">
        <header className="mock-panel-head">
          <h2>EVENTS OVER TIME</h2>
          <span className="mock-panel-meta">last 2h · 5m granularity</span>
        </header>
        <div className="mock-chart">
          <svg viewBox={`0 0 ${SERIES.length * 40} 200`} preserveAspectRatio="none" className="mock-chart-svg">
            {/* gridlines */}
            {[0, 50, 100, 150, 200].map(y => (
              <line key={y} x1={0} x2={SERIES.length * 40} y1={y} y2={y} className="mock-chart-grid" />
            ))}
            {/* delivered */}
            <polyline
              className="mock-chart-line line-delivered"
              points={SERIES.map((s, i) => `${i * 40 + 20},${200 - (s.delivered / maxSeries) * 180}`).join(' ')}
            />
            {/* posted */}
            <polyline
              className="mock-chart-line line-posted"
              points={SERIES.map((s, i) => `${i * 40 + 20},${200 - (s.posted / maxSeries) * 180}`).join(' ')}
            />
            {/* rejected */}
            <polyline
              className="mock-chart-line line-rejected"
              points={SERIES.map((s, i) => `${i * 40 + 20},${200 - (s.rejected / maxSeries) * 180}`).join(' ')}
            />
          </svg>
          <div className="mock-chart-x">
            {SERIES.map((s, i) =>
              i % 4 === 0 ? <span key={i}>{s.time}</span> : <span key={i} />,
            )}
          </div>
          <div className="mock-chart-legend">
            <span className="lg-dot d-delivered" /> delivered
            <span className="lg-dot d-posted" /> posted
            <span className="lg-dot d-rejected" /> rejected
          </div>
        </div>
      </section>

      <section className="mock-grid-3">
        <div className="mock-panel">
          <header className="mock-panel-head">
            <h2>REJECTIONS BY REASON</h2>
          </header>
          <ul className="mock-bar-list">
            {REJECTIONS_BY_REASON.map(r => (
              <li key={r.reason}>
                <span className="lbl">{r.reason}</span>
                <span className="bar">
                  <span className="bar-fill" style={{ width: `${(r.count / maxRejection) * 100}%` }} />
                </span>
                <span className="num">{r.count}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="mock-panel">
          <header className="mock-panel-head">
            <h2>TOP REJECTED NPUBS</h2>
          </header>
          <ul className="mock-bar-list">
            {TOP_NPUBS.map(r => (
              <li key={r.npub}>
                <span className="lbl mono">{r.npub}</span>
                <span className="bar">
                  <span className="bar-fill" style={{ width: `${(r.count / maxNpub) * 100}%` }} />
                </span>
                <span className="num">{r.count}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="mock-panel">
          <header className="mock-panel-head">
            <h2>TOP REJECTED IPS</h2>
          </header>
          <ul className="mock-bar-list">
            {TOP_IPS.map(r => (
              <li key={r.ip}>
                <span className="lbl mono">{r.ip}</span>
                <span className="bar">
                  <span className="bar-fill" style={{ width: `${(r.count / maxIp) * 100}%` }} />
                </span>
                <span className="num">{r.count}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}

function KpiCard(props: { label: string; value: string; unit: string; trend?: string; tone?: 'warn' }) {
  return (
    <div className={`mock-kpi ${props.tone === 'warn' ? 'tone-warn' : ''}`}>
      <span className="mock-kpi-label">{props.label}</span>
      <span className="mock-kpi-value">{props.value}</span>
      <span className="mock-kpi-foot">
        <span>{props.unit}</span>
        {props.trend && <span className="mock-kpi-trend">{props.trend}</span>}
      </span>
    </div>
  );
}
