import type { ReactNode } from 'react';
import { useState } from 'react';
import { IP_RULES, LIVE_EVENTS, RELAY_INFO } from '../fixtures';
import type { IpMode } from '../types';

interface Props {
  themeId: string;
  decoration?: ReactNode;
}

interface NavItem {
  group: string;
  items: { id: string; label: string; active?: boolean }[];
}

const NAV: NavItem[] = [
  {
    group: 'OVERVIEW',
    items: [
      { id: 'dashboard', label: 'Dashboard' },
      { id: 'live', label: 'Live Events' },
      { id: 'logs', label: 'Logs' },
    ],
  },
  {
    group: 'BACKEND',
    items: [
      { id: 'relays', label: 'Backend Relays' },
      { id: 'nip11', label: 'NIP-11' },
    ],
  },
  {
    group: 'ACCESS CONTROL',
    items: [
      { id: 'post-policy', label: 'POST Policy' },
      { id: 'npub', label: 'Npub' },
      { id: 'ip', label: 'IP ACL', active: true },
      { id: 'quarantine', label: 'Quarantine' },
    ],
  },
  {
    group: 'FILTERING',
    items: [
      { id: 'kind', label: 'Kind Blacklist' },
      { id: 'filters', label: 'Filter Rules' },
      { id: 'simple-ban', label: 'Simple BAN' },
    ],
  },
  {
    group: 'OPERATIONS',
    items: [{ id: 'metrics', label: 'Metrics' }],
  },
];

export function ConfigSampleTemplate({ themeId, decoration }: Props) {
  const [rules, setRules] = useState(IP_RULES);

  const updateMode = (idx: number, mode: IpMode) => {
    setRules(rs => rs.map((r, i) => (i === idx ? { ...r, mode } : r)));
  };

  return (
    <div className={`mock mock-cfg theme-${themeId}`} data-theme={themeId}>
      {decoration}
      <aside className="mock-side">
        <div className="mock-side-brand">
          <span className="mock-mark" />
          <span className="mock-side-name">{RELAY_INFO.name}</span>
        </div>
        {NAV.map(g => (
          <div className="mock-side-group" key={g.group}>
            <div className="mock-side-group-label">{g.group}</div>
            {g.items.map(it => (
              <a
                key={it.id}
                className={`mock-side-item ${it.active ? 'active' : ''}`}
                href="#"
                onClick={e => e.preventDefault()}
              >
                <span className="dot" />
                {it.label}
              </a>
            ))}
          </div>
        ))}
        <div className="mock-side-foot">
          <span>v0.4.0-mock</span>
        </div>
      </aside>

      <main className="mock-cfg-main">
        <header className="mock-cfg-head">
          <span className="mock-eyebrow">/ ACCESS CONTROL / IP ACL</span>
          <h1>IP Access Control</h1>
          <p className="mock-cfg-lead">
            <b>Hard BAN</b> 接続を拒否し既存セッションを強制切断 ·{' '}
            <b>Shadow BAN</b> 接続は通すが REQ/EVENT を黙殺 ·{' '}
            <b>Whitelist</b> 他の BAN を上書き
          </p>
        </header>

        <section className="mock-cfg-grid">
          <div className="mock-cfg-card mock-cfg-card-wide">
            <header className="mock-cfg-card-head">
              <h2>RULES</h2>
              <div className="mock-cfg-card-actions">
                <button className="mock-btn mock-btn-secondary">+ Add IP / CIDR</button>
              </div>
            </header>
            <table className="mock-table">
              <thead>
                <tr>
                  <th>IP / CIDR</th>
                  <th>MODE</th>
                  <th>MEMO</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {rules.map((r, i) => (
                  <tr key={r.ip}>
                    <td className="mono">
                      {r.ip}
                      {r.is_cidr && <span className="mock-tag">CIDR</span>}
                    </td>
                    <td>
                      <span className={`mock-mode mode-${r.mode}`}>{r.mode.toUpperCase()}</span>
                      <select
                        className="mock-select"
                        value={r.mode}
                        onChange={e => updateMode(i, e.target.value as IpMode)}
                      >
                        <option value="normal">normal</option>
                        <option value="whitelist">whitelist</option>
                        <option value="shadow_ban">shadow_ban</option>
                        <option value="hard_ban">hard_ban</option>
                      </select>
                    </td>
                    <td>{r.memo}</td>
                    <td>
                      <button className="mock-btn mock-btn-ghost">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mock-cfg-card">
            <header className="mock-cfg-card-head">
              <h2>LIVE STREAM</h2>
              <span className="mock-pill">SSE</span>
            </header>
            <div className="mock-stream">
              {LIVE_EVENTS.map((ev, i) => (
                <div className={`mock-stream-row ev-${ev.type}`} key={i}>
                  <span className="t">{ev.ts}</span>
                  <span className={`badge bd-${ev.type}`}>{label(ev.type)}</span>
                  <span className="d">
                    {ev.kind != null && <span>kind={ev.kind}</span>}
                    {ev.npub && <span className="mono">{ev.npub}</span>}
                    {ev.ip && <span className="mono">ip={ev.ip}</span>}
                    {ev.reason && <span className="r">{ev.reason}</span>}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function label(t: string): string {
  switch (t) {
    case 'event_accepted':
      return 'POST OK';
    case 'event_rejected':
      return 'POST RJ';
    case 'event_delivered':
      return 'DELIV';
    case 'event_dropped':
      return 'DROP';
    case 'connection_opened':
      return 'CONN+';
    case 'connection_closed':
      return 'CONN-';
    default:
      return t;
  }
}
