export type ThemeId =
  | 'terminal'
  | 'nasa'
  | 'tron'
  | 'alien'
  | 'synthwave'
  | 'bladerunner'
  | 'watchdogs'
  | 'cyberpunk'
  | 'ratchet'
  | 'gta_phone'
  | 'lol'
  | 'apex'
  | 'hybrid';

export interface ThemeMeta {
  id: ThemeId;
  name: string;
  tagline: string;
  description: string;
  palette: string[];
}

export interface MockRelayInfo {
  name: string;
  description: string;
  region: string;
  policy: string;
  supported_nips: number[];
  contact: string;
  url: string;
}

export interface MockKpi {
  active_connections: number;
  posted_per_min: number;
  delivered_per_min: number;
  rejected_per_min: number;
  uptime_label: string;
  uptime_seconds: number;
}

export interface MockSeriesPoint {
  time: string;
  posted: number;
  delivered: number;
  rejected: number;
}

export type IpMode = 'normal' | 'whitelist' | 'shadow_ban' | 'hard_ban';

export interface MockIpRule {
  ip: string;
  mode: IpMode;
  is_cidr: boolean;
  memo: string;
}

export type LiveEventType =
  | 'event_accepted'
  | 'event_rejected'
  | 'event_delivered'
  | 'event_dropped'
  | 'connection_opened'
  | 'connection_closed';

export interface MockLiveEvent {
  ts: string;
  type: LiveEventType;
  kind?: number;
  npub?: string;
  ip?: string;
  reason?: string;
  sub_id?: string;
}

export interface MockFeature {
  title: string;
  body: string;
  icon: string;
}

export interface MockUseCase {
  title: string;
  body: string;
}

export interface MockRejectionByReason {
  reason: string;
  count: number;
}

export interface MockTopNpub {
  npub: string;
  count: number;
}

export interface MockTopIp {
  ip: string;
  count: number;
}

export interface ThemeAssets {
  meta: ThemeMeta;
  /** Optional theme-specific decoration component (e.g. CRT scanlines, grid overlay). */
  Decoration?: React.FC;
}
