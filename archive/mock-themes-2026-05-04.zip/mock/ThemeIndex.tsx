import { Link } from 'react-router-dom';
import type { ThemeMeta } from './types';

export function ThemeIndex({ theme }: { theme: ThemeMeta }) {
  return (
    <div className="mock-index">
      <header className="mock-index-head">
        <span className="mock-index-eyebrow">// {theme.name} / VARIANT</span>
        <h1 className="mock-index-title">{theme.name}</h1>
        <p className="mock-index-lead">{theme.description}</p>
      </header>
      <div className="mock-index-card-actions" style={{ maxWidth: 600 }}>
        <Link to="lp">LP</Link>
        <Link to="dashboard">DASHBOARD</Link>
        <Link to="config">CONFIG</Link>
        <Link to="/">← ALL THEMES</Link>
      </div>
    </div>
  );
}
