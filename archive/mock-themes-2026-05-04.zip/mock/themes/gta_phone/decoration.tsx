export function GtaPhoneDecoration() {
  return <div className="gta-bg" />;
}
