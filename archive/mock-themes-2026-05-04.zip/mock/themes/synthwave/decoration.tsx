export function SynthwaveDecoration() {
  return (
    <>
      <div className="synth-sun" />
      <div className="synth-grid" />
    </>
  );
}
