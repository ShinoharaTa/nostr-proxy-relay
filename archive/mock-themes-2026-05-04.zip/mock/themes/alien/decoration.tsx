export function AlienDecoration() {
  return (
    <>
      <div className="alien-warn-overlay" />
      <div className="alien-stripes" />
      <div className="alien-stripes-bot" />
    </>
  );
}
