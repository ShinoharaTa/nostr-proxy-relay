export function BladerunnerDecoration() {
  return (
    <>
      <div className="br-haze" />
      <div className="br-dust" />
    </>
  );
}
