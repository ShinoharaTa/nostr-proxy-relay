export function LolDecoration() {
  return <div className="lol-hex" />;
}
