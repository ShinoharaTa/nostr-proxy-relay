export function ApexDecoration() {
  return <div className="apex-slash" />;
}
