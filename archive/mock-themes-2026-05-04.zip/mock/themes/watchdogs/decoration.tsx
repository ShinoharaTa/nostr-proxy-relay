export function WatchdogsDecoration() {
  return <div className="wd-net" />;
}
