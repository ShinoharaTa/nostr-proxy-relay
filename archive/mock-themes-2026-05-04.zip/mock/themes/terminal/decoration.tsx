export function TerminalDecoration() {
  return <div className="term-crt" />;
}
