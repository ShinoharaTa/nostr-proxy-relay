export function NasaDecoration() {
  return <div className="nasa-bg" />;
}
