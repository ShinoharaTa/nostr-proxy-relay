export function RatchetDecoration() {
  return <div className="rc-holo" />;
}
