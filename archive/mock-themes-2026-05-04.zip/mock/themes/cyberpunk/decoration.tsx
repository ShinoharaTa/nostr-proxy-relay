export function CyberpunkDecoration() {
  return (
    <>
      <div className="cp-noise" />
      <div className="cp-rail" />
    </>
  );
}
