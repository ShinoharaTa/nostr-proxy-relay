export function HybridDecoration() {
  return (
    <>
      <div className="hb-noise" />
      <div className="hb-rail" />
      <div className="hb-crt" />
    </>
  );
}
