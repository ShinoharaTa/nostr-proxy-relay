export function TronDecoration() {
  return <div className="tron-grid" />;
}
